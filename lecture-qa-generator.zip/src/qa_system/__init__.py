"""
QA System Package
講義内容の確認QAの作成システム
"""

__version__ = "0.1.0"
__author__ = "AI Engineering Team"
__description__ = "AI-powered Q&A generation system for lecture content"